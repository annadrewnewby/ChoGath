export default  class Component{
    constructor(gameObject){
        this.gameObject = gameObject;
    }
}