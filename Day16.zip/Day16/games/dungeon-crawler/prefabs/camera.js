export default {
  name: "MainCamera", components: [
    { name: "WorldCameraComponent" }
  ],sx:20, sy:20
}