export default {
  name:"KeyboardBumpRectangle",
  children:[],
  components:[
    {
      name:"DrawComponent",
      args:["white"]
    },
    {
      name:"KeyboardBumpComponent",
      args:[2]
    }

  ]
}