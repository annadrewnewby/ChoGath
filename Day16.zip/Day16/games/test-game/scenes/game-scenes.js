export {default as FirstScene} from "./first-scene.js"
export {default as MainScene} from "./main-scene.js"
export {default as SecondScene} from "./second-scene.js"
